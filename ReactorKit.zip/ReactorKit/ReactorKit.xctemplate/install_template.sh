asdf
#!/bin/bash

# Define the URL of your template.
TEMPLATE_URL="https://example.com/path/to/your/template.zip"

# Define the destination directory.
DEST_DIR="~/Library/Developer/Xcode/Templates/File Templates/Custom Templates/"

# Download the template file.
curl -L -o template.zip $TEMPLATE_URL

# Unzip the template file.
unzip template.zip

# Move the template to the Xcode templates directory.
mv MyTemplate.xctemplate "$DEST_DIR"

# Clean up the downloaded zip file.
rm template.zip

echo "Template installed successfully!"
