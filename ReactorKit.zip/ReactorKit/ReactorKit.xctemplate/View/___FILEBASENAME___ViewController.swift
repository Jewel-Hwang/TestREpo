//___FILEHEADER___

import ReactorKit
//import ReusableKit
import RxDataSources
import RxCocoa
import RxSwift
import RxOptional
import RxViewController
import SnapKit
import Device
import ManualLayout

public protocol ___FILEBASENAMEASIDENTIFIER___ViewControllerType {
    
}

public final class ___FILEBASENAMEASIDENTIFIER___ViewController: BaseViewControllerA, ___FILEBASENAMEASIDENTIFIER___ViewControllerType, View {
    
    public typealias Reactor = ___FILEBASENAMEASIDENTIFIER___Reactor
    
    
    // MARK: Constant
    
    fileprivate struct Constant {
    }
    
    fileprivate struct Metric {
    }
    
    fileprivate struct Font {
    }
    
    public struct AttributedText {

    }
    
    fileprivate struct Color {
    }
    
    fileprivate struct Image {
    }
    
    // MARK: Property
    
    // MARK: UI
    
    // MARK: Initialize
    
    public init(
        reactor: Reactor
    ) {
        defer { self.reactor = reactor }
        
        super.init()
    }
    
    public required convenience init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: View Life Cycle
    
    override public func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override public func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    // MARK: Layout
    
    override public func layoutCommon() {
        super.layoutCommon()
        
    }
    
    public override func layoutPhone() {
        super.layoutPhone()
        
    }
    
    public override func layoutPad() {
        super.layoutPad()
        
    }
    
    public override func layoutGuideLinesTop() -> ConstraintItem {
        return super.layoutGuideLinesTop()
    }
    
    // MARK: Configure
    
    public override func setUpUI() {
        super.setUpUI()
    }
    
    public override func updateUI() {
        super.updateUI()
    }
    
    // MARK: Bind
    
    public func bind(reactor: Reactor) {
        self.bindAction(reactor)
        self.bindState(reactor)
        self.bindView(reactor)
    }
    
    // MARK: Bind - Action
    
    public func bindAction(_ reactor: Reactor) {
//        self.rx.viewDidLoad
//            .map { Reactor.Action.refresh }
//            .bind(to: reactor.action )
//            .disposed(by: self.disposeBag)
    }
    
    // MARK: Bind - State
    
    public func bindState(_ reactor: Reactor) {
        self.bindStateLoading(reactor)
        self.bindStateError(reactor)
        self.bindStateAlert(reactor)
        self.bindStateMessage(reactor)
    }
    
    public func bindStateLoading(_ reactor: Reactor) {
        reactor.state
            .map { $0.isLoading }
            .distinctUntilChanged()
            .subscribe({ [weak self] (event) in
                if let isLoading = event.element {
                    if isLoading {
                        self?.startAnimating()
                    } else {
                        self?.stopAnimating()
                    }
                }
            })
            .disposed(by: self.disposeBag)
    }
    
    public func bindStateError(_ reactor: Reactor) {
        reactor.state
            .map { $0.error }.filterNil()
            .mapChangedTracked({ $0 }).filterNil()
            .subscribe(onNext: { [weak self] (error) in
                log.debug("Error - Title:\(error.title)), Code: \(error.code)), Description: \(error.description))")
                self?.showAlert(message: error.description)
            })
            .disposed(by: self.disposeBag)
    }
    
    public func bindStateAlert(_ reactor: Reactor) {
        reactor.state
            .map { $0.alert }.filterNil()
            .mapChangedTracked({ $0 }).filterNil()
            .subscribe(onNext: { [weak self] (message) in
                log.debug("\(message.localized)")
                self?.showAlert(message: message.localized)
            })
            .disposed(by: self.disposeBag)
    }
    
    public func bindStateMessage(_ reactor: Reactor) {
        reactor.state
            .map { $0.message }.filterNil()
            .mapChangedTracked({ $0 }).filterNil()
            .subscribe(onNext: { [weak self] (message) in
                log.debug("\(message)")
                self?.showAlert(message: message)
            })
            .disposed(by: self.disposeBag)
    }
    
    // MARK: Bind - View
    
    public func bindView(_ reactor: Reactor) {
        
    }
    
    // MARK: Event


    // MARK: Action
}

