//___FILEHEADER___

import Foundation
import ReactorKit
import RxCocoa
import RxSwift
import Moya

public final class ___FILEBASENAMEASIDENTIFIER___Reactor: Reactor {
    
    
    private let startLoading = Observable<Mutation>.just(.setLoading(true))
    private let endLoading = Observable<Mutation>.just(.setLoading(false))
    
    public enum Action {
        case refresh
    }
    
    public enum Mutation {
        case setLoading(Bool)
        case setItems([Item])
        case setError(Error?)
        case setAlert(LocalizeString?)
        case setMessage(String?)
    }
    
    public struct State {
        var isLoading: Bool = false
        var items: [Item] = []
        var error: Error?
        var alert: LocalizeString?
        var message: String?
    }
    
    public let initialState: State = State()
    
    // MARK: Initializing
    
    init() {
        
    }
    
    // MARK: Transform
    
    func transform(action: Observable<Action>) -> Observable<Action> {
        return action
    }
    
    func transform(mutation: Observable<Mutation>) -> Observable<Mutation> {
        return mutation
    }
    
    func transform(state: Observable<State>) -> Observable<State> {
        return state
    }
    
    // MARK: Reduce
    
    func reduce(state: State, mutation: Mutation) -> State {
        var state = state
        
        switch mutation {
        case let .setLoading(isLoading):
            state.isLoading = isLoading
        case let .setItems(items):
            state.items = items
        case let .setError(error):
            state.error = error
        case let .setAlert(alert):
            state.alert = alert
        case let .setMessage(message):
            state.message = message
        }
        
        return state
    }
    
    // MARK: Mutation
    
    func mutate(action: Action) -> Observable<Mutation> {
        switch action {
        case .refresh:
            return Observable.concat([
                startLoading,
                endLoading
            ])
        }
    }
}
